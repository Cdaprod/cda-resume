# Penetration Testing Achievements

Blog: Sanity.Cdaprod.dev
Github: Github.com/Cdaprod
Last edited time: May 20, 2023 3:49 PM
Owner: David Cannan
Status: Self made
Verification: Verified

## Summary of Career Accomplishments

David Cannan has successfully transitioned from a diverse professional background into the field of Information Technology, specifically targeting penetration testing and risk assessment. This transition, driven by a deep passion for cybersecurity, demonstrates David's adaptability, resilience, and ability to learn independently. While pursuing CompTIA Security+ & Juniper (JNCIA) certifications, David has amassed a wide array of technical skills, ranging from programming languages to cloud computing, and has applied these skills to practical projects to enhance his understanding and proficiency.

## Top Three Achievements

### 1. Successful Career Transition

David's decision to transition from a successful career in woodworking, photography, and small business ownership to the field of Information Technology, specifically penetration testing and risk assessment, is no small feat. This move displays David's adaptability, resilience, and ability to learn independently. While running his businesses, David has been pursuing relevant certifications and expanding his technical skill set. His commitment to this new career path is demonstrated by his ongoing pursuit of CompTIA Security+ & Juniper (JNCIA) certifications.

### 2. Diverse Technical Proficiency

David's technical skills span a wide range of areas, from Linux command line, BASH, Python, C++, HTML/CSS, JS, JSON, YAML, and Dockerfile to AWS IAM, API authentication, and VLAN/VPC networking. This broad technical proficiency, largely self-taught, showcases David's ability to learn new technologies quickly and apply them effectively. It also underscores his understanding of various aspects of IT, making him a versatile candidate for roles in penetration testing and risk assessment.

### 3. Practical Cybersecurity Projects

David has worked on several practical projects to gain hands-on experience in his field of interest. These projects include IoT reverse engineering, open-source intelligence (OSINT), reconnaissance, cross-site scripting, and Wi-Fi data collection. Notably, he has successfully implemented attacks at home to build target and replicate environments for ethical hacking. He has also utilized cloud computing to build and secure domains and servers and practice penetration testing. This practical experience will be invaluable in a professional setting, demonstrating David's ability to apply his knowledge and skills to real-world scenarios.